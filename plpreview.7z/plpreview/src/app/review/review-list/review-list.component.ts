import { Component, OnInit } from '@angular/core';
import { Review } from 'src/app/review';
import { ReviewsService } from 'src/app/reviews.service';
import { EditComponent } from '../edit/edit.component';


@Component({
  selector: 'app-review-list',
  templateUrl: './review-list.component.html',
  styleUrls: ['./review-list.component.css']
})
export class ReviewListComponent implements OnInit {
reviews:Review[];
reviewData:Review={"index":0,"id":0,"bookTitle":'',"rating":0,"customerName":'',"headLine":'',"comments":'',"reviewDate":''};
  constructor(private service:ReviewsService) { }

  ngOnInit() {
    this.service.getAllReviews().subscribe((data:Review[])=>{this.reviews=data;
    });
  }

  deleteReview(review:Review){
    if (window.confirm(" Are you sure you want to delete the review with id "+review.id)) { 
    //window.open("review", "Thanks for Visiting!");
    this.service.deleteReview(review).subscribe((data)=>{this.reviews=this.reviews.filter(c=>c!==review)});
    }
  }

  editReview(review:Review){
    this.service.getById(review.id).subscribe((data)=>{this.reviews=this.reviews.filter(c=>c!==review)});
    }
  }
    
    