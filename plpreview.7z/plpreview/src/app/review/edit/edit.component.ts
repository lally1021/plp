import { Component, OnInit } from '@angular/core';
import { Review } from 'src/app/review';
import { ReviewsService } from 'src/app/reviews.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  review:Review[];
  reviewData:Review={"index":0,"id":0,"bookTitle":"","rating":0,"customerName":'',"headLine":'',"comments":'',"reviewDate":''};
  constructor(private service:ReviewsService,private router:Router,private route:ActivatedRoute) { }


  ngOnInit() {
    this.route.params.subscribe(
      (params)=>{this.service.getById(params['id'])
      .subscribe((result)=>{this.reviewData=result;})}
      );
  }
  edit(){
   console.log(this.reviewData);
    this.service.editReview(this.reviewData).subscribe((data)=>{this.router.navigate(['']);});}
  }