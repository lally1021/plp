import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Review } from './review';

@Injectable({
  providedIn: 'root'
})
export class ReviewsService {
reviews:Review[];
reviewData:Review={"index":0,"id":0,"bookTitle":'',"rating":0,"customerName":'',"headLine":'',"comments":'',"reviewDate":''};
  url:string="http://localhost:3000";
  constructor(private http:HttpClient) { }
getAllReviews(){
  return this.http.get<Review[]>(this.url+"/review");
}
getById(id:number){
  return this.http.get<Review>(this.url+"/review/"+id)
}
deleteReview(review:Review){
  return this.http.delete<Review[]>(this.url+"/reviews/"+review.id);
}
  editReview(review:Review){

    return this.http.put(this.url+"/reviews/"+review.id,review);
  }
  
}