import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ReviewListComponent } from './review/review-list/review-list.component';
import { EditComponent } from './review/edit/edit.component';



const routes: Routes = [
  {path:'',component:ReviewListComponent},
  {path:"edit",component:EditComponent},
  {path:"edit/:id",component:EditComponent},
  {path:"review",component:ReviewListComponent}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
