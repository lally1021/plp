package com.capgemini.parallelProject.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.capgemini.parallelProject.bean.Account;
import com.capgemini.parallelProject.bean.Transaction;
import com.capgemini.parallelProject.exception.AccountException;
import com.capgemini.parallelProject.utility.DBConnection;

public class AccountDaoImpl implements AccountDao{

	Connection connection=null;
	PreparedStatement statement=null;
	ResultSet resultSet=null;
	boolean status=false;
	int row=-1;
	private Connection con = null;
	@Override
	public long addAccount(Account account) {
		int custId=0;
		try(Connection connection=DBConnection.getConnection();) {
			statement=connection.prepareStatement("select account_seq.NEXTVAL from dual");
			resultSet=statement.executeQuery();
			if(resultSet.next()) {
				
			statement=connection.prepareStatement("insert into account values(?,?,?,?,?)");
			statement.setLong(1, account.getAccountNo());
			statement.setLong(2,account.getBalance());
			statement.setString(3,account.getName());
			statement.setString(4, account.getGender());
			statement.setString(5, account.getMobileNo());
			row=statement.executeUpdate();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return custId;
	}
	public long withdrawl(long accountNo, long amountWithdrawl) throws AccountException {
	Connection connection=DBConnection.getConnection();
	long balance=0,balance1=0;
	     try {
	         statement=connection.prepareStatement("select balance from account where accountno=?");
	         statement.setLong(1, accountNo);
	         ResultSet rs=statement.executeQuery();
	         while(rs.next())
	         {   
	        	 balance=rs.getLong(1);
	             statement=connection.prepareStatement("update account set balance=? where accountno=?");
	     
	        	 
	        /*Account acc = null;
			// Account acc = rs.next();
	         long acNo =acc.getAccountNo();
	             balance=acc.getBalance();
	             statement=connection.prepareStatement("update account set balance=? where accountno=?");
	            
	            
	     			if (acNo == accountNo) {
	     				if(balance>amountWithdrawl) {
	     				balance = balance - amountWithdrawl;
	     				acc.setBalance(balance);
	     				}else {
	     					throw new AccountException("balance is insufficient");
	     				}
	     			}*/
	             
	             balance1=balance-amountWithdrawl;
	             statement.setLong(1, balance1);
	             statement.setLong(2, accountNo);
	          statement.executeUpdate();
	         } 
	         }catch (SQLException e) {
	             e.printStackTrace();
	          }
	     
	       return balance1;
	}

	@Override
	public long deposit(long accountNumber, long depositedAmount) {
		// TODO Auto-generated method stub
		Connection connection=DBConnection.getConnection();
		long balance=0,balance1=0;
		     try {
		         statement=connection.prepareStatement("select balance from account where accountno=?");
		         statement.setLong(1, accountNumber);
		         ResultSet rs=statement.executeQuery();
		         while(rs.next())
		         {              
		             balance=rs.getLong(1);
		             statement=connection.prepareStatement("update account set balance=? where accountno=?");
		             balance1=balance+depositedAmount;
		             statement.setLong(1, balance1);
		             statement.setLong(2, accountNumber);
		          statement.executeUpdate();
		         } 
		         }catch (SQLException e) {
		             e.printStackTrace();
		          }
		     
		       return balance1;
	}

	public long getBalance(long accountNo) {

		Connection connection=DBConnection.getConnection();
        long balance=0;
             try {
                 statement=connection.prepareStatement("select balance from account where accountno=?");
                 statement.setLong(1, accountNo);
                 ResultSet rs=statement.executeQuery();
                 while(rs.next())
                 {             
                     balance=rs.getLong(1);  
                 }

             } catch (SQLException e) {
               e.printStackTrace();
            }
         return balance;
       
   
	}

	@Override
	public void addTransaction(Transaction transaction) throws AccountException {
		
		Connection connection=DBConnection.getConnection();
		ResultSet rs;
	
   		
   		try  {

   		 

            statement = connection.prepareStatement("select transaction_seq.NEXTVAL from dual");
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
               // status = true;
                statement = connection.prepareStatement("insert into transaction values(?,?,?,?,?,?)");
                statement.setInt(1, transaction.getTransactionId());
                statement.setString(2, transaction.getTransactionType());
//                Date sqldob = new Date(transaction.getTransactionDate().getTime());
//                statement.setDate(3, sqldob);
//                statement.setLong(4, transaction.getCustomerid());
                statement.setLong(3, transaction.getSenderAccountNo());
                statement.setLong(4,transaction.getReceiverAccountNo() );
                statement.setLong(5, transaction.getTransferedAmount());
                statement.setLong(6, transaction.getBalance());

 

                row = statement.executeUpdate();
            }
        } catch (SQLException e) {

 

            System.out.println(e.getMessage());
        }
		
	}

	@Override
	public long fundTransfer(long senderAccountNo, long recieverAccountNo, long transferAmount) throws AccountException {
		// TODO Auto-generated method stub
		long accBal,balance1=0,balance2=0;
		Connection connection=DBConnection.getConnection();
		ResultSet rs;
		int i;
		
		try {
			statement=connection.prepareStatement("select balance from account where accountno=?");
            statement.setLong(1, senderAccountNo);
           
            rs=statement.executeQuery();
            while(rs.next())
            {   
            	accBal=rs.getLong(1);
            	if(accBal>=transferAmount)
            	{
            	 statement=connection.prepareStatement("update account set balance=? where accountno=?");
            	 balance1=accBal-transferAmount;
            	 statement.setLong(1, balance1);
            	 statement.setLong(2, senderAccountNo);
            	 i=statement.executeUpdate();
            	 
            	 statement=connection.prepareStatement("select balance from account where accountno=?");
            	 statement.setLong(1, recieverAccountNo);
            	 rs=statement.executeQuery();
            	 while(rs.next())
            	 {
            		 accBal=rs.getLong(1);
            		 statement=connection.prepareStatement("update account set balance=? where accountno=?");
            		 balance2=accBal+transferAmount;
            		 statement.setLong(1, balance2);
                	 statement.setLong(2, recieverAccountNo);
                	 statement.executeUpdate();
            	 }
            	}
            	else throw new AccountException("Insufficient Balance");
            }
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return balance1;
	}

	public void ptr(long accno) {
		try {
			statement=connection.prepareStatement("select transaction from transactions where senderAccountNo=?");
			statement.setLong(1, accno);
			ResultSet rs=statement.executeQuery();
			while(rs.next())
			{
				System.out.println(rs.getString(1));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public List<Transaction> viewTransactions(int transId) throws AccountException {
		// TODO Auto-generated method stub
		List<Transaction> list1 = new ArrayList<>();
		Transaction transaction = new Transaction();
		Connection connection = DBConnection.getConnection();
		ResultSet rs;

		try {
			statement = connection.prepareStatement("select * from transaction where senderAccountNo=?");

			statement.setLong(1, transId);
			ResultSet resultSet = statement.executeQuery();

			while (resultSet.next()) {
				transaction.setTransactionId(resultSet.getInt("transactionId"));
				transaction.setTransactionType(resultSet.getString("transactionType"));
			
				transaction.setSenderAccountNo(resultSet.getLong("senderAccountNo"));
				transaction.setReceiverAccountNo(resultSet.getLong("receiverAccountNo"));
				transaction.setTransferedAmount(resultSet.getLong("transferedAmount"));
				transaction.setBalance(resultSet.getLong("balance"));

				System.out.println(transaction);
			}
		} catch (SQLException e) {

			System.out.println(e.getMessage());

		}

		return list1;

	}

}
