package com.capgemini.parallelProject.dao;

import java.util.Set;

import com.capgemini.parallelProject.bean.Account;
import com.capgemini.parallelProject.bean.Transaction;
import com.capgemini.parallelProject.exception.AccountException;

public interface AccountDao {

	public long deposit(long accountNumber, long depositedAmount);
//
//	//public long createTransaction(Transaction transaction);
//
	public long getBalance(long accountNo);

	public long addAccount(Account account);

	public long withdrawl(long accountNo, long amountWithdrawl) throws AccountException;
//
	public long fundTransfer(long senderAccountNo, long recieverAccountNo, long transferAmount) throws AccountException;
//
	void addTransaction(Transaction transaction) throws AccountException;
//
//	public Set<Transaction> printTransaction() throws AccountException;
	
}
