package com.capgemini.parallelProject.service;

import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.parallelProject.bean.Account;
import com.capgemini.parallelProject.bean.Transaction;
import com.capgemini.parallelProject.dao.AccountDao;
import com.capgemini.parallelProject.dao.AccountDaoImpl;
import com.capgemini.parallelProject.exception.AccountException;

public class AccountServiceImpl {

	AccountDaoImpl accountDao = new AccountDaoImpl();


	public boolean validateName(String name) throws AccountException {
		// TODO Auto-generated method stub
		boolean resultFlag = false;
		String nameRegEx = "[A-Z]{1}[a-zA-Z ]{5,}";

		if (!Pattern.matches(nameRegEx, name)) {
			throw new AccountException("first letter should be capital and length should be gt 5");
		} else {
			resultFlag = true;
		}
		return resultFlag;
	}


	public boolean validateNumber(String mobileNo) throws AccountException {
		// TODO Auto-generated method stub
		boolean resultFlag = false;
		String mobile = String.valueOf(mobileNo);
		Pattern nameptn = Pattern.compile("^[7-9]{1}[0-9]{9}$");
		Matcher match = nameptn.matcher(mobile);
		if (match.matches()) {
			resultFlag=true;
		}
		else {
			throw new AccountException("first letter should be between 7-9 and the length should be 10");
		}
		return false;
	}

	/*@Override
	public boolean validateAccountNumber(long accountNo) throws AccountException {
		// TODO Auto-generated method stub
		boolean resultFlag = false;
		String number = String.valueOf(accountNo);
		Pattern nameptn = Pattern.compile("^[0-9]{7}$");
		Matcher match = nameptn.matcher(number);
		if (match.matches()) {
			resultFlag=true;
		}
		else {
			throw new AccountException("Account number should contain only numbers and its length should be 7");
		}
		return false;
	}*/


	public boolean validateAmount(double amount) throws AccountException {
		// TODO Auto-generated method stub
		boolean amountFlag = false;

		if (amount < 500) {
			throw new AccountException("cost should not be lt 0");
		} else {
			amountFlag = true;
		}
		return amountFlag;
	}


	public long generateId() throws AccountException {
		// TODO Auto-generated method stub
				long accountNo =(long) (Math.random() * 100000000L); 
				return accountNo;
	}

	
	public long addAccount(Account account) {
		// TODO Auto-generated method stub
		return accountDao.addAccount(account);	
	}


	public long withdrawl(long accountNo, long amountWithdrawl) throws AccountException {
		// TODO Auto-generated method stub
		return accountDao.withdrawl(accountNo, amountWithdrawl);
}
	
	public int transacId() {
		int transactionId =(int) (Math.random() * 1000); 
	return transactionId;
	}


	public long deposit(long accountNo, int amountDeposited) {
		// TODO Auto-generated method stub
		return accountDao.deposit(accountNo, amountDeposited);
	}


	public long getBalance(long accountNo) {
		// TODO Auto-generated method stub
		return accountDao.getBalance(accountNo);
	}


	public void addTransaction(Transaction transaction) throws AccountException {
		// TODO Auto-generated method stub
		accountDao.addTransaction(transaction);
		
	}


	public long fundTransfer(long senderAccountNo, long recieverAccountNo, int transferAmount) throws AccountException{
		// TODO Auto-generated method stub
		return accountDao.fundTransfer(senderAccountNo, recieverAccountNo, transferAmount);
	}

	public void ptr(long accno) {
		accountDao.ptr(accno);
		
	}


	public List<Transaction> viewTransactions(int transId) throws AccountException {
		// TODO Auto-generated method stub
		return accountDao.viewTransactions(transId);
	}
	
}
