package com.capgemini.parallelProject.bean;

import java.time.LocalDate;

public class Transaction {
	int transactionId;
	String transactionType;
	//LocalDate transactionDate;
	long senderAccountNo;
	long receiverAccountNo;
	long transferedAmount;
	long balance;
	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Transaction(int transactionId, String transactionType, long senderAccountNo, long receiverAccountNo,
			long transferedAmount, long balance) {
		super();
		this.transactionId = transactionId;
		this.transactionType = transactionType;
		this.senderAccountNo = senderAccountNo;
		this.receiverAccountNo = receiverAccountNo;
		this.transferedAmount = transferedAmount;
		this.balance = balance;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public long getSenderAccountNo() {
		return senderAccountNo;
	}
	public void setSenderAccountNo(long senderAccountNo) {
		this.senderAccountNo = senderAccountNo;
	}
	public long getReceiverAccountNo() {
		return receiverAccountNo;
	}
	public void setReceiverAccountNo(long receiverAccountNo) {
		this.receiverAccountNo = receiverAccountNo;
	}
	public long getTransferedAmount() {
		return transferedAmount;
	}
	public void setTransferedAmount(long transferedAmount) {
		this.transferedAmount = transferedAmount;
	}
	public long getBalance() {
		return balance;
	}
	public void setBalance(long balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", transactionType=" + transactionType
				+ ", senderAccountNo=" + senderAccountNo + ", receiverAccountNo=" + receiverAccountNo
				+ ", transferedAmount=" + transferedAmount + ", balance=" + balance + "]";
	}
	
}