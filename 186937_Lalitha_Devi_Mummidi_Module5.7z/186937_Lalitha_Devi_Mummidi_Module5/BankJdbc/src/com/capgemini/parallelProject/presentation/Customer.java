package com.capgemini.parallelProject.presentation;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import com.capgemini.parallelProject.bean.Account;
import com.capgemini.parallelProject.bean.Transaction;
import com.capgemini.parallelProject.exception.AccountException;
import com.capgemini.parallelProject.service.AccountService;
import com.capgemini.parallelProject.service.AccountServiceImpl;

public class Customer {
	public static void main(String[] args) throws AccountException {

		String continueChoice;
		boolean continueValue = false;

		Scanner scanner = null;
		do {

			System.out.println("*** welcome to Banking***");
			System.out.println("1.Create Account");
			System.out.println("2.Deposit");
			System.out.println("3.Withdraw");
			System.out.println("4.Fund Transfer");
			System.out.println("5.Show Balance");
			System.out.println("6.Print Transactions");
			System.out.println("7.exit");

			AccountServiceImpl service = new AccountServiceImpl();

			int choice = 0;
			boolean choiceFlag = false;

			do {

				scanner = new Scanner(System.in);
				System.out.println("Enter input:");

				try {
					scanner = new Scanner(System.in);
					choice = scanner.nextInt();
					choiceFlag = true;

					boolean flag = false;

					int balance = 0;
					int bal = 0;
					int amountDeposited = 0;
					int transferAmount = 0;
					long accountNo = 0;
					long accNo = 0;
					int amountWithdrawl, transId = 0;

					switch (choice) {
					case 1: {

						String name = "";

						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter name:");
							name = scanner.next();
							try {
								service.validateName(name);
								flag = true;
							} catch (AccountException e) {
								flag = false;
								System.err.println(e.getMessage());
							}
						} while (!flag);

						String mobileNo = "";

						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter mobile number:");
							mobileNo = scanner.next();
							try {
								service.validateNumber(mobileNo);
								flag = true;
							} catch (AccountException e) {
								flag = false;
								System.err.println(e.getMessage());
							}
						} while (!flag);

						String gender = "";

						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Gender:");
							gender = scanner.next();
							if (gender.equals("male")) {
								gender = "Male";
								flag = true;
							} else if (gender.equals("female")) {
								gender = "Female";
								flag = true;
							} else {
								System.out.println(
										"gender should be in characters and it should be either male or female");
								flag = false;
							}
						} while (!flag);

						balance = 0;

						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter balance:");
							balance = scanner.nextInt();
							try {
								service.validateAmount(balance);
								flag = true;
							} catch (AccountException e) {
								flag = false;
								System.err.println(e.getMessage());
							}
						} while (!flag);

						accountNo = service.generateId();
						System.out.println("account created with the given id: " + accountNo);
						Account account = new Account(accountNo, balance, name, gender, mobileNo);
						service.addAccount(account);
					}
						break;

					case 2:

					{

						System.out.println("Enter account number for deposit:");
						accountNo = scanner.nextLong();
						System.out.println("Enter amount to be deposited:");
						scanner = new Scanner(System.in);
						amountDeposited = scanner.nextInt();
						long balanceAfterDeposit = service.deposit(accountNo, amountDeposited);

						System.out.println("balance after deposit is:" + balanceAfterDeposit);

						int transacId = service.transacId();

						Transaction transaction = new Transaction(transId, "deposit", accountNo, 0, transferAmount,
								balanceAfterDeposit);

						service.addTransaction(transaction);

					}
						break;
					//
					case 3: {
						System.out.println("Enter account number for withdrawl:");
						accountNo = scanner.nextLong();
						System.out.println("Enter amount to be withdrawn:");
						scanner = new Scanner(System.in);
						amountWithdrawl = scanner.nextInt();
						LocalDate date = LocalDate.now();

						long balanceAfterWithdrawl = service.withdrawl(accountNo, amountWithdrawl);

						System.out.println("balance after withdrawl is:" + balanceAfterWithdrawl);

						int transacId = service.transacId();

						Transaction transaction = new Transaction(transacId, "withdrawl", accountNo, 0, transferAmount,
								balanceAfterWithdrawl);
						service.addTransaction(transaction);
					}
						break;
					case 4: {
						scanner = new Scanner(System.in);
						System.out.println("Enter your account number:");
						long senderAccountNo = scanner.nextLong();

						System.out.println("Enter reciever's account number:");
						long recieverAccountNo = scanner.nextLong();

						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter amount to be transferred:");
							transferAmount = scanner.nextInt();

							try {
								service.validateAmount(transferAmount);
								flag = true;
							} catch (AccountException e) {
								flag = false;
								System.err.println(e.getMessage());
							}

						} while (!flag);
						transId = service.transacId();
						long balanceAfterTransaction = service.fundTransfer(senderAccountNo, recieverAccountNo,
								transferAmount);
						System.out.println("balance after transaction is:" + balanceAfterTransaction);
						int transacId = service.transacId();
						Transaction transaction = new Transaction(transId, "fundTransfer", senderAccountNo,
								recieverAccountNo, transferAmount, balanceAfterTransaction);
						service.addTransaction(transaction);
					}
						break;

					case 5: {
						scanner = new Scanner(System.in);
						System.out.println("Enter your account number:");
						accountNo = scanner.nextLong();
						long balance2 = service.getBalance(accountNo);
						System.out.println("Your account balance is:" + balance2);
					}
						break;
					case 6: {

						System.out.println("enter your account number");
						scanner = new Scanner(System.in);
						transId = scanner.nextInt();
						System.out.println("your transactions are as below");
						List<Transaction> list11 = new ArrayList<>();
						try {
							list11 = service.viewTransactions(transId);
							//System.out.println(list11);
						} catch (AccountException e) {

							e.printStackTrace();
						}
					}
						break;

					case 7:
						System.out.println("Thank u, visit again");
						System.exit(0);
						break;

					default:
						System.out.println("input should be 1,2,3,4 or 5");
						choiceFlag = false;
						break;

					}
				} catch (InputMismatchException exception) {
					choiceFlag = false;
					System.err.println("input should contain only digits");
				}

			} while (!choiceFlag);

			do {
				scanner = new Scanner(System.in);
				System.out.println("do you want to continue again [yes/no]");
				continueChoice = scanner.nextLine();
				if (continueChoice.equalsIgnoreCase("yes")) {
					continueValue = true;
					break;
				} else if (continueChoice.equalsIgnoreCase("no")) {
					System.out.println("thank you");
					continueValue = false;
					break;
				} else {
					System.out.println("enter yes or no");
					continueValue = false;
					continue;
				}
			} while (!continueValue);

		} while (continueValue);
		scanner.close();
	}
}
