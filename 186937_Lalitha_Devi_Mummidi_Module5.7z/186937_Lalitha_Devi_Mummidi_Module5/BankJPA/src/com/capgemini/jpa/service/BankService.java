package com.capgemini.jpa.service;

import com.capgemini.jpa.bean.Account;
import com.capgemini.jpa.exception.BankException;

public interface BankService {
	
	long addAccountDetails(Account account) throws BankException;
	 public boolean isNameValid(String name) throws BankException;
	 public boolean isPhoneValid(long phone) throws BankException;
	 public boolean isBalanceValid(long balance) throws BankException;
	 long addDeposit(long accountNo, long depositAmount) throws BankException;
	 long afterWithdraw(long accountNo, long withdrawAmount) throws BankException;
	 long fundTransfer(long accountNo, long fundTransferAmount) throws BankException;
	 long showBalance(long accountNo) throws BankException;

}
