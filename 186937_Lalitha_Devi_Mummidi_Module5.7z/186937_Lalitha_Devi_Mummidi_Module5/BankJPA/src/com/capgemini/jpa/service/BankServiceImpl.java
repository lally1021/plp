package com.capgemini.jpa.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.jpa.bean.Account;
import com.capgemini.jpa.dao.BankDao;
import com.capgemini.jpa.dao.BankDaoImpl;
import com.capgemini.jpa.exception.BankException;

public class BankServiceImpl implements BankService {

	BankDao dao=new BankDaoImpl();
	@Override
	public long addAccountDetails(Account account) throws BankException {
		
		return dao.addAccount(account);
	}
	@Override
	public boolean isNameValid(String name) throws BankException{
		Pattern nameptn=Pattern.compile("^[A-Z]{1}[a-z]{4,}$");
		Matcher match=nameptn.matcher(name);
		if(match.matches()) {
			return true;
		}
		return false;
	}
	@Override
	public boolean isPhoneValid(long phone) throws BankException{
		String mobile=String.valueOf(phone);
		Pattern mobileptn=Pattern.compile("^[7-9]{1}[0-9]{9}$");
		Matcher match=mobileptn.matcher(mobile);
		if(match.matches()) {
			return true;
		}
		return false;
	}
	@Override
	public boolean isBalanceValid(long balance) throws BankException {
		boolean balanceFlag=false;
		if(balance<1000) {
			throw new BankException("Sorry, the minimum balance in the account should be 1000 and not less than that");
		}else {
			balanceFlag=true;
		}
		return balanceFlag;
	}
	@Override
	public long addDeposit(long accountNo, long depositeAmount) throws BankException {
		// TODO Auto-generated method stub
		return dao.addDeposit(accountNo, depositeAmount);
	}
	@Override
	public long afterWithdraw(long accountNo, long withdrawAmount) throws BankException {
		// TODO Auto-generated method stub
		return dao.afterWithdraw(accountNo, withdrawAmount);
	}
	@Override
	public long fundTransfer(long accountNo, long fundTransferAmount) throws BankException {
		
		return dao.fundTransfer(accountNo, fundTransferAmount);
	}
	@Override
	public long showBalance(long accountNo) throws BankException {
		
		return dao.showBalance(accountNo);
	}
	
	

}
