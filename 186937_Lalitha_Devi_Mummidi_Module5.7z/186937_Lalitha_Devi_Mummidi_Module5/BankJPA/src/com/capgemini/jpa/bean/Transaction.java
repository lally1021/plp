package com.capgemini.jpa.bean;

import java.util.Date;

public class Transaction {
	private int transactionId;
	private Date transactionDate;
	private long accountNumber;
	private double balance;
	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Transaction(int transactionId, Date transactionDate, long accountNumber, double balance) {
		super();
		this.transactionId = transactionId;
		this.transactionDate = transactionDate;
		this.accountNumber = accountNumber;
		this.balance = balance;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public Date getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}
	public long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", transactionDate=" + transactionDate
				+ ", accountNumber=" + accountNumber + ", balance=" + balance + "]";
	}
	
	

}
