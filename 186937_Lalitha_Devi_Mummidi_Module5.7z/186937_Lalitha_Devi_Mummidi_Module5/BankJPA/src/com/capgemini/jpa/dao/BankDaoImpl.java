package com.capgemini.jpa.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.capgemini.jpa.bean.Account;
import com.capgemini.jpa.exception.BankException;

public class BankDaoImpl implements BankDao {
	EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
    EntityManager manager=factory.createEntityManager();
    TypedQuery<Account> query;
    long balance;
	@Override
	public long addAccount(Account account) throws BankException{
		manager.getTransaction().begin();
		manager.persist(account);
		manager.getTransaction().commit();
		return account.getAccountNo();
	}

	@Override
	public long addDeposit(long accountNo, long depositAmount) throws BankException{
		long remainBalance=0;
		manager.getTransaction().begin();
		Account account=manager.find(Account.class, accountNo);
		remainBalance=account.getBalance();
		account.setBalance(remainBalance+depositAmount);
		manager.getTransaction().commit();
		return remainBalance+depositAmount;
	}

	@Override
	public long afterWithdraw(long accountNo, long withdrawAmount) throws BankException{
		long remainBalance=0;
		manager.getTransaction().begin();
		Account account=manager.find(Account.class, accountNo);
		remainBalance=account.getBalance();
		account.setBalance(remainBalance-withdrawAmount);
		manager.getTransaction().commit();
		return remainBalance-withdrawAmount;
	}

	

	@Override
	public long fundTransfer(long accountNo, long fundTransferAmount) throws BankException{
		long remainBalance=0;
		manager.getTransaction().begin();
		Account account=manager.find(Account.class, accountNo);
		remainBalance=account.getBalance();
		account.setBalance(remainBalance-fundTransferAmount);
		manager.getTransaction().commit();
		return remainBalance-fundTransferAmount;
	}

	@Override
	public long showBalance(long accountNo) throws BankException {
		long remainingBalance=0;
		manager.getTransaction().begin();
		Account account=manager.find(Account.class, accountNo);
		remainingBalance=account.getBalance();
		manager.getTransaction().commit();
		return remainingBalance;
	}

}
