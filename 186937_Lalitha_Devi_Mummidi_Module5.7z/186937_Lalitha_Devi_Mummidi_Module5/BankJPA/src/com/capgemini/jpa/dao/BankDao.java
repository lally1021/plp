package com.capgemini.jpa.dao;

import com.capgemini.jpa.bean.Account;
import com.capgemini.jpa.exception.BankException;

public interface BankDao {
	public long addAccount(Account account) throws BankException;
	public long addDeposit( long accountNo , long depositAmount) throws BankException;
	public long afterWithdraw(long accountNo, long withdrawAmount) throws BankException;
	public long showBalance(long accountNo) throws BankException;
	public long fundTransfer(long accountNo, long fundTransferAmount) throws BankException;

	
	

}
