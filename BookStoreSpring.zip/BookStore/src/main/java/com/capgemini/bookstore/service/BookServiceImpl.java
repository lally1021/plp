package com.capgemini.bookstore.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bookstore.beans.Book;
import com.capgemini.bookstore.beans.Category;
import com.capgemini.bookstore.dao.BookRepository;
import com.capgemini.bookstore.exception.BookStoreException;


@Service
public class BookServiceImpl implements BookService{

	@Autowired
	BookRepository dao;
	
	@Override
	public List<Book> addBook(Book book) {
		dao.save(book);
		return getAllBooks();
	}

	@Override
	public List<Book> getAllBooks() {
		return dao.findAll();
	}

	@Override
	public List<Book> deleteBook(int id) throws BookStoreException {
		try {
			if (dao.exists(id)) {
				dao.delete(id);
				return getAllBooks();
			} else {
				throw new BookStoreException("Book with Id: " + id + " does not exists.");
			}
		} catch (Exception e) {
			throw new BookStoreException(e.getMessage());
		}
	}

	@Override
	public List<Book> editBook(Book book) throws BookStoreException {
		try {
			if (dao.exists(book.getId())) {
				dao.save(book);
				return getAllBooks();
			} else {
				throw new BookStoreException("invalid edit");
			}
		} catch (Exception e) {

			throw new BookStoreException("invalid updation");
		}
	}

	@Override
	public Book getById(int id) throws BookStoreException {
		try {
			Book data = dao.findOne(id);
			if (data != null) {
				return data;
			} else {
				throw new BookStoreException("Book id : " + id + "does not exist.");
			}
		} catch (Exception e) {
			throw new BookStoreException(e.getMessage());
		}
	}

	@Override
	public void deleteBookByCategory(Category category) throws BookStoreException {
		
		
	}

}
