package com.capgemini.bookstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bookstore.beans.User;
import com.capgemini.bookstore.dao.UserRepository;
import com.capgemini.bookstore.exception.BookStoreException;



@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private UserRepository UserDAO;

	
	@Override
	public List<User> createUser(User user) throws BookStoreException {
		UserDAO.save(user);
		return getAllUser();
	}

	@Override
	public List<User> getAllUser() throws BookStoreException {
		return UserDAO.findAll();
	}

	@Override
	public User getUserById(int id) throws BookStoreException {
		return UserDAO.findOne(id);
	}

	@Override
	public List<User> editUser(User user, int id) throws BookStoreException {
		if(UserDAO.exists(id)) {
		UserDAO.save(user);
		}
		return getAllUser();
	}

	@Override
	public List<User> deleteUser(int id) throws BookStoreException {
		UserDAO.delete(id);
		return getAllUser();
	}

	@Override
	public User findByIdPass(String email, String password) {
		User user=UserDAO.findByEmail(email);
		if(user.getPassword().equals(password)) {
			return user;
		}
		else {
			return null;
		}
	}

}
