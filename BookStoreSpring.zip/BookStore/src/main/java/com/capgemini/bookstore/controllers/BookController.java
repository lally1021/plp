package com.capgemini.bookstore.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.bookstore.beans.Book;
import com.capgemini.bookstore.exception.BookStoreException;
import com.capgemini.bookstore.service.BookService;



@CrossOrigin("*")
@RestController
public class BookController {
	@Autowired
	BookService service;
	
	@PostMapping("/book")
	public List<Book> addBook(@RequestBody Book book) {
		System.out.println("add book");
		System.out.println(book);
		return service.addBook(book);
	}
	@GetMapping("/book")
	public List<Book> getAllBooks(){
		return service.getAllBooks();
	}
	
	
	@DeleteMapping("/book/{id}")
	public List<Book> deleteBook(@PathVariable int id) throws BookStoreException{
	return service.deleteBook(id);
	}
	@PutMapping("/book")
	public List<Book> editBook(@RequestBody Book book) throws BookStoreException{
		return service.editBook(book);
	}
	@GetMapping("/book/{id}")
	public Book getById(@PathVariable int id) throws BookStoreException{
		return service.getById(id);
	}
}
