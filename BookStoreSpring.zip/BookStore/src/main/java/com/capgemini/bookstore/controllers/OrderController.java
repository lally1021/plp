package com.capgemini.bookstore.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.bookstore.beans.Order;
import com.capgemini.bookstore.beans.OrderedBook;
import com.capgemini.bookstore.exception.BookStoreException;
import com.capgemini.bookstore.service.BookService;
import com.capgemini.bookstore.service.OrderService;
import com.capgemini.bookstore.service.OrderedBooksService;

@CrossOrigin("*")
@RestController
public class OrderController {

	@Autowired
	OrderService orderService;
	
	@Autowired
	OrderedBooksService orderedBookService;
	
	@GetMapping("/orders")
    public List<Order> getAllOrders() throws BookStoreException {
        return orderService.getAllOrders();
    }
    
  
    
    @GetMapping("/order/{id}")
    public Order geOrderById(@PathVariable int id) throws BookStoreException {
      return orderService.getOrderById(id);
    }
    
    @GetMapping("/orderedBooks/{id}")
    public List<OrderedBook> getAllOrderedBook(@PathVariable int id ) throws BookStoreException {
        return orderedBookService.getAllOrderedBooks(id);
    }
    
}
