package com.capgemini.bookstore.service;

import java.util.List;

import com.capgemini.bookstore.beans.User;
import com.capgemini.bookstore.exception.BookStoreException;




public interface UserService {

	List<User> createUser(User user) throws BookStoreException ;
	List<User> deleteUser(int id) throws BookStoreException ;
	List<User> editUser(User user,int id) throws BookStoreException ;
	List<User> getAllUser() throws BookStoreException ;
	User getUserById(int id) throws BookStoreException;
	User findByIdPass(String email, String password);
	
}

