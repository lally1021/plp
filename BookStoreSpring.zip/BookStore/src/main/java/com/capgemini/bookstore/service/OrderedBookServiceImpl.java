package com.capgemini.bookstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bookstore.beans.Order;
import com.capgemini.bookstore.beans.OrderedBook;
import com.capgemini.bookstore.dao.OrderedBookRepository;

@Service
public class OrderedBookServiceImpl implements OrderedBooksService {

	@Autowired
	OrderedBookRepository dao;

	@Override
	public List<OrderedBook> getAllOrderedBooks(int orderId) {
		// TODO Auto-generated method stub
		return null;
	}

	
	
	
}
