package com.capgemini.bookstore.service;

import java.util.List;

import com.capgemini.bookstore.beans.Review;
import com.capgemini.bookstore.exception.BookStoreException;




public interface ReviewService {
	List<Review> getAllReviews() throws BookStoreException;
	List<Review> editReview(int id,Review review) throws BookStoreException;
	List<Review> deleteReview(int id) throws BookStoreException;
	List<Review> addReview(Review review) throws BookStoreException;
	Review getById(int id ) throws BookStoreException;
}
