package com.capgemini.bookstore.service;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bookstore.beans.Order;
import com.capgemini.bookstore.beans.OrderedBook;
import com.capgemini.bookstore.dao.OrderRepository;
import com.capgemini.bookstore.dao.OrderedBookRepository;
import com.capgemini.bookstore.exception.BookStoreException;

@Service
public class OrderServiceImpl implements OrderService {

@Autowired OrderRepository dao;
@Autowired OrderedBookRepository orderedBook;
    
    @Override
    public List<Order> getAllOrders() throws BookStoreException{
    	
    	
        return dao.findAll();
    }

 

    @Override
    public Order getOrderById(int id) throws BookStoreException {
        try {
            Order data=dao.findOne(id);
            if(data != null) {
                return data;
            }
            else {
                throw new BookStoreException("User with the id "+id+" doesnot exist");
}
        } catch (Exception e) {
            // TODO Auto-generated catch block
            throw new BookStoreException(e.getMessage());
        }
    }

 

    @Override
    public Order saveOrder(Order order) throws BookStoreException {
        dao.save(order);
        return order;
    }

}
