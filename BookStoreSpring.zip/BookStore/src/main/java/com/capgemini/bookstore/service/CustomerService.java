package com.capgemini.bookstore.service;

import java.util.List;

import com.capgemini.bookstore.beans.Customer;
import com.capgemini.bookstore.exception.BookStoreException;



public interface CustomerService {
	
	List<Customer> getAllCustomers() throws BookStoreException;
    List<Customer> addCustomer(Customer customer) throws BookStoreException;
    List<Customer> registerCustomer(Customer customer) throws BookStoreException;
    List<Customer> profileCust(Customer customer) throws BookStoreException;
    List <Customer> deleteCustomer(int id)throws BookStoreException;
	List<Customer> editCustomer(Customer customer) throws BookStoreException;
	Customer getCustomerById(int id) throws BookStoreException;
	Customer login(String email,String password)throws BookStoreException;
    
}
