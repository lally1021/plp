package com.capgemini.bookstore;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.capgemini.bookstore.beans.Book;
import com.capgemini.bookstore.beans.Category;
import com.capgemini.bookstore.beans.Customer;
import com.capgemini.bookstore.beans.Order;
import com.capgemini.bookstore.beans.OrderedBook;
import com.capgemini.bookstore.beans.Review;
import com.capgemini.bookstore.dao.CategoryRepository;
import com.capgemini.bookstore.dao.UserRepository;
import com.capgemini.bookstore.service.CategoryService;
import com.capgemini.bookstore.service.CategoryServiceImpl;

@SpringBootApplication
public class BookStoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookStoreApplication.class, args);
		
		/*
		 * Customer customer = new Customer(11, "customer11@gmail.com", "Customer11",
		 * "customer11", "9876543210", "Pune", "Pune", "country", "zipcode", new
		 * Date()); Customer customer2 = new Customer(12, "customer12@gmail.com",
		 * "Customer12", "customer12", "9876543211", "Pune2", "Pune2", "country2",
		 * "zipcode2", new Date()); Category category = new Category(11, "Category1");
		 * Category category2 = new Category(12, "Category2"); Book book = new Book(11,
		 * category2, "title", "author", "isbn", new Date(), "bookImage", 500.00,
		 * "description"); Book book2 = new Book(12, category, "title3", "author3",
		 * "isbn3", new Date(), "bookImage3", 800.00, "description3");
		 * 
		 * OrderedBook orderedBook = new OrderedBook(11, book2, 5); OrderedBook
		 * orderedBook2 = new OrderedBook(12, book, 7); List<OrderedBook> orderedBooks =
		 * new LinkedList<>(); orderedBooks.add(orderedBook);
		 * orderedBooks.add(orderedBook2); Order order = new Order(11, "paymentMethod",
		 * "status", new Date(), "recipientName", "recipientPhone", "shipTo",
		 * orderedBooks, customer2); Order order2 = new Order(12, "paymentMethod",
		 * "status", new Date(), "recipientName", "recipientPhone", "shipTo",
		 * orderedBooks, customer); Review review = new Review(11, "bookTitle", 4.5,
		 * "customerName", "headLine", "comment", new Date()); Review review2 = new
		 * Review(12, "bookTitle", 3.5, "customerName", "headLine", "comment", new
		 * Date()); Review review3 = new Review(13, "bookTitle", 4.0, "customerName",
		 * "headLine", "comment", new Date()); List<Review> reviews = new
		 * LinkedList<>(); reviews.add(review); reviews.add(review2);
		 * reviews.add(review3); book.setReviews(reviews); book2.setReviews(reviews);
		 * CategoryServiceImpl categoryServiceImpl = new CategoryServiceImpl();
		 * categoryServiceImpl.addCategory(category);
		 */
		 
	}
}