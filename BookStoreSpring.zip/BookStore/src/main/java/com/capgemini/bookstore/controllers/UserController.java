package com.capgemini.bookstore.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.capgemini.bookstore.beans.Order;
import com.capgemini.bookstore.beans.User;
import com.capgemini.bookstore.exception.BookStoreException;
import com.capgemini.bookstore.service.OrderService;
import com.capgemini.bookstore.service.UserService;
import com.capgemini.bookstore.utils.SampleResponse;
import com.capgemini.bookstore.utilsre.utils.BookStoreRequestModel;

import java.util.HashMap;
import java.util.List;

import javax.validation.Valid;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/user")
public class UserController {

	/*
	 * @Autowired private UserService userService;
	 * 
	 * @Autowired private OrderService orderService;
	 * 
	 * @RequestMapping("/greet") public String sayHello() { return "hello"; }
	 * 
	 * @PostMapping(path = {"/users"}) public User create(@RequestBody User user){
	 * return userService.create(user); }
	 * 
	 * @GetMapping(path = {"/users/{email}/{password}"}) public User
	 * findUser(@PathVariable("email") String email,@PathVariable("password") String
	 * password){ System.out.println(email); return userService.findByIdPass(email,
	 * password); }
	 * 
	 * @PutMapping(path = {"/users/{id}"}) public User update(@PathVariable("id")
	 * int id, @RequestBody User user){ user.setId(id); return
	 * userService.update(user); }
	 * 
	 * @DeleteMapping("/users/{id}") public User delete(@PathVariable("id") int id)
	 * { return userService.delete(id); }
	 * 
	 * @GetMapping("/users") public List<User> findAll(){ return
	 * userService.findAll(); }
	 * 
	 * // @PostMapping(value = "/validuser") // public
	 * ResponseEntity<SampleResponse> fundTransfer(@Valid @RequestBody
	 * BookStoreRequestModel requestModel) // throws BookStoreException { //
	 * System.out.println(requestModel.getEmail()+" "+requestModel.getPassword());
	 * // User validatedUser=userService.findByIdPass(requestModel.getEmail(),
	 * requestModel.getPassword()); // HashMap<String, Object> data = new
	 * HashMap<String, Object>(); // data.put("user",validatedUser ); //
	 * System.out.println(validatedUser); // // SampleResponse sampleRespose = new
	 * SampleResponse(true, data); // ResponseEntity<SampleResponse> response = new
	 * ResponseEntity<SampleResponse>(sampleRespose, // HttpStatus.ACCEPTED); //
	 * return response; // }
	 * 
	 * 
	 * 
	 * @GetMapping("/orders") public List<Order> findAllOrder(){
	 * 
	 * Order HashMap<String, Object> data = new HashMap<String, Object>();
	 * data.put(); System.out.println(validatedUser);
	 * 
	 * SampleResponse sampleRespose = new SampleResponse(true, data);
	 * ResponseEntity<SampleResponse> response = new
	 * ResponseEntity<SampleResponse>(sampleRespose, HttpStatus.ACCEPTED); return
	 * response; return orderService.getAllOrders(); }
	 */

	@Autowired
	private UserService service;

	@PostMapping
	public List<User> createUser(@RequestBody User user) throws BookStoreException {
		return service.createUser(user);
	}

	@GetMapping
	public List<User> getAllUser() throws BookStoreException {
		return service.getAllUser();
	}

	@DeleteMapping("{id}")
	public List<User> deleteUser(@PathVariable int id) throws BookStoreException {
		return service.deleteUser(id);
	}

	@GetMapping("{id}")
	public User getUserById(@PathVariable int id) throws BookStoreException {
		return service.getUserById(id);
	}
	
	@PutMapping("{id}")
	public List<User> editUser(@RequestBody User user,@PathVariable int id) throws BookStoreException {
		return service.editUser(user, id);
	}
	@GetMapping(path = {"{email}/{password}"}) public User
	  findUser(@PathVariable("email") String email,@PathVariable("password") String
	  password){ System.out.println(email); return service.findByIdPass(email,
	  password); }
}
