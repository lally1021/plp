package com.capgemini.bookstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.bookstore.beans.Order;
import com.capgemini.bookstore.beans.OrderedBook;

public interface OrderedBookRepository extends JpaRepository<OrderedBook, Integer>{
	
}
