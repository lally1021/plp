package com.capgemini.bookstore.service;

import java.util.List;

import com.capgemini.bookstore.beans.Book;
import com.capgemini.bookstore.beans.Category;
import com.capgemini.bookstore.exception.BookStoreException;



public interface BookService {

	public List<Book> addBook(Book book);
	public List<Book> getAllBooks();
	public List<Book> deleteBook(int id) throws BookStoreException;
	public List<Book> editBook(Book book) throws BookStoreException;
	public Book getById(int id) throws BookStoreException;
	public void deleteBookByCategory(Category category) throws BookStoreException;
}
