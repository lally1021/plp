package com.capgemini.bookstore.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.bookstore.beans.Customer;
import com.capgemini.bookstore.exception.BookStoreException;
import com.capgemini.bookstore.service.CustomerService;



@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/customer")
public class CustomerController {

	@Autowired
	private CustomerService custService;

	@PostMapping("/create")
	public List<Customer> addcustomer(@RequestBody Customer customer) throws BookStoreException {

		return custService.addCustomer(customer);

	}

	@GetMapping("/list")
	public List<Customer> getAllCustomers() throws BookStoreException {

		List<Customer> customers = custService.getAllCustomers();

		return customers;
	}
	@GetMapping("/profile")
	public List<Customer> profileCust() throws BookStoreException {

		List<Customer> customers = custService.getAllCustomers();

		return customers;
	}
	@GetMapping("/login/{email}/{password}")
	public Customer login(@PathVariable String email,@PathVariable String password) throws BookStoreException {

	 

		return custService.login(email, password);
	}
	@DeleteMapping("/{id}")
	public List<Customer> deleteCustomer(@PathVariable int id) throws BookStoreException {
		System.out.println("id = " + id);
		return custService.deleteCustomer(id);
	}

	@PutMapping("/edit")
	public List<Customer> editCustomer(@RequestBody Customer customer) throws BookStoreException {
		return custService.editCustomer(customer);
	}
	
	@GetMapping("/customer/{id}")
	public Customer getCustomerById(@PathVariable int id) throws BookStoreException {
		return custService.getCustomerById(id);

	}
	@PostMapping("/register")
	public List<Customer> registerCustomer(@RequestBody Customer customer) throws BookStoreException {
System.out.println(customer);
		return custService.registerCustomer(customer);

	}

}