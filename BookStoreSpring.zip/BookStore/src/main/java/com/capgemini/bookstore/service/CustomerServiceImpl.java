package com.capgemini.bookstore.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bookstore.beans.Customer;
import com.capgemini.bookstore.dao.CustomerRepository;
import com.capgemini.bookstore.exception.BookStoreException;



@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerRepository custDao;

	@Override
	public List<Customer> getAllCustomers() throws BookStoreException {
		return custDao.findAll();
	}

	@Override
	public List<Customer> addCustomer(Customer customer) throws BookStoreException {

		custDao.save(customer);
		return getAllCustomers();
	}

	/*
	 * @Override public List<Customer> deleteCustomer(Customer customer,int id)
	 * throws CustomerException { if (custDao.existsById(id)) {
	 * custDao.deleteById(id); return getAllCustomers(); } else { throw new
	 * CustomerException("customer with id" + id + "does not exist"); } }
	 */

	@Override
	public List<Customer> editCustomer(Customer customer) throws BookStoreException {
		if (custDao.exists(customer.getId())) {
			custDao.save(customer);
			return getAllCustomers();
		} else {
			throw new BookStoreException("Invalid customer. Cannot update");
		}
	}

	@Override
	public List<Customer> deleteCustomer(int id) throws BookStoreException {
		if (custDao.exists(id)) {
			custDao.delete(id);
			return getAllCustomers();
		} else {
			throw new BookStoreException("customer with id" + id + "does not exist");
		}
	}

	@Override
	public Customer getCustomerById(int id) throws BookStoreException {
		try {
			Customer data = custDao.findOne(id);
			if (data != null) {
				return data;
			} else {
				throw new BookStoreException("Customer with Id " + id + " does not exist");
			}
		} catch (Exception e) {
			throw new BookStoreException(e.getMessage());
		}
	}

	@Override
	public List<Customer> profileCust(Customer customer) throws BookStoreException {
		
		return custDao.findAll();
	}

	@Override
	public List<Customer> registerCustomer(Customer customer) throws BookStoreException {
		custDao.save(customer);
		return getAllCustomers();
		
	}

	@Override
	public Customer login(String email, String password) throws BookStoreException {
	
		Customer customer = custDao.findByEmail(email);
		System.out.println(customer);
		System.out.println(customer.getPassword());
		System.out.println(password);
		if(customer.getPassword().equalsIgnoreCase(password)) {
			return customer;
		}
		else {
			return null;
		}
	
	
	}
}
