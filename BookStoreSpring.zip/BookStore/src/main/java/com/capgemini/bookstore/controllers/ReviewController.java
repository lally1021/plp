package com.capgemini.bookstore.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.bookstore.beans.Review;
import com.capgemini.bookstore.exception.BookStoreException;
import com.capgemini.bookstore.service.ReviewService;



@CrossOrigin(origins="*")
@RestController
public class ReviewController {
	@Autowired
	public ReviewService reviewService;

	
	@GetMapping("/review")
	public List<Review> getAllReviews() throws BookStoreException {
		return reviewService.getAllReviews();
	}
	
	@PutMapping("/reviews/{id}")
	public List<Review> editReviews(@PathVariable int id,@RequestBody Review review) throws BookStoreException{
		return reviewService.editReview(id, review);
	}
	
	@DeleteMapping("/reviews/{id}")
	public List<Review> deleteReviews(@PathVariable int id) throws BookStoreException{
		return reviewService.deleteReview(id);
	}
	@PostMapping("/reviews")
	public List<Review> addReview(@RequestBody Review review) throws BookStoreException{
		return reviewService.addReview(review);
	}
	
	@GetMapping("/review/{id}")
	public Review getById(@PathVariable int id)  throws BookStoreException{ 
		return reviewService.getById(id);
	}
}
