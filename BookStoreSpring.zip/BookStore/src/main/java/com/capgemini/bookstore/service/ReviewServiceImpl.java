package com.capgemini.bookstore.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bookstore.beans.Review;
import com.capgemini.bookstore.dao.ReviewRepository;
import com.capgemini.bookstore.exception.BookStoreException;





@Service
public class ReviewServiceImpl implements ReviewService{

	@Autowired
	private ReviewRepository dao;
	@Override
	public List<Review> getAllReviews() throws BookStoreException {

		try {
			return dao.findAll();
		} catch (Exception e) {
			throw new BookStoreException(e.getMessage());	
			}
	}

	@Override
	 public List<Review> editReview(int id,Review review) throws BookStoreException {
		try {
			if(dao.exists(review.getId())) {
				/*
				 * Review rev=dao.findById(id).get(); rev.setHeadLine(review.getHeadLine());
				 * rev.setComments(review.getComments());
				 */
				/*
				 * SimpleDateFormat format = new SimpleDateFormat("dd/mm/yyyy");
				 * 
				 * String dateString = format.format( new Date() ); review.setDate(dateString);
				 */
				dao.save(review);
				System.out.println(getAllReviews());
				return getAllReviews();
			}
			else {
				throw new BookStoreException("invalid review id,cannot edit");
			}
		} catch (Exception e) {
			throw new BookStoreException(e.getMessage());	
		}
	}

	@Override
	public List<Review> deleteReview(int id) throws BookStoreException {
		if(dao.exists(id)) {
			dao.delete(id);
			return getAllReviews();
		}
		else {
			throw new BookStoreException("cannot Delete. Review with Id "+id+" does not exist");
		}
	}

	@Override
	public List<Review> addReview(Review review) throws BookStoreException {
		try {
			dao.save(review);
			return getAllReviews();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new BookStoreException(e.getMessage());	
		}
	}

	@Override
	public Review getById(int id) throws BookStoreException {
		try {
			Review data= dao.findOne(id);
			if(data != null) {
				return data;
			}
			else {
				throw new BookStoreException("Employee with id"+id+"does not exist");
			}
		} catch (Exception e) {
			throw new BookStoreException(e.getMessage());	
		}
	}

}
