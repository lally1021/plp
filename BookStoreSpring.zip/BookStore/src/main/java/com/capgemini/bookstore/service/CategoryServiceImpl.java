package com.capgemini.bookstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bookstore.beans.Category;
import com.capgemini.bookstore.dao.BookRepository;
import com.capgemini.bookstore.dao.CategoryRepository;


@Service
public class CategoryServiceImpl implements CategoryService {
	
	@Autowired
    private CategoryRepository catgdao;
	
	@Autowired
	   private BookRepository bookDao;
	@Override
	public List<Category> getAllCategories() {
		
		return catgdao.findAll();
	}

	@Override
	public List<Category> addCategory(Category category) {
		catgdao.save(category);
		return getAllCategories();
	}

	@Override
	public List<Category> updateCategory(int id,Category category) {
		if(catgdao.exists(id)) {
		catgdao.save(category);
		}
		return getAllCategories();
		
	}

	@Override
	public List<Category> deleteCategory(int id) {
		bookDao.deleteAllByCategoryId(id);
		System.out.println("pahucha");
		catgdao.delete(id);
		return getAllCategories();
	}

	@Override
	public Category getByid(int id) {
		// TODO Auto-generated method stub
		return catgdao.findOne(id);
	}

}

