package com.capgemini.bookstore.service;

import java.util.List;

import com.capgemini.bookstore.beans.Order;
import com.capgemini.bookstore.beans.OrderedBook;

public interface OrderedBooksService {
	List<OrderedBook> getAllOrderedBooks(int orderId);
}
