package com.capgemini.bookstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.bookstore.beans.Book;
import com.capgemini.bookstore.beans.Category;

@Repository
public interface BookRepository extends JpaRepository<Book, Integer> {

	List<Book> deleteAllByCategoryId(int id);
}
