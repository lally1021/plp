package com.capgemini.bookstore.service;

import java.util.List;

import com.capgemini.bookstore.beans.Order;
import com.capgemini.bookstore.exception.BookStoreException;

public interface OrderService {

	List<Order> getAllOrders() throws BookStoreException;

	Order saveOrder(Order order) throws BookStoreException;

	public Order getOrderById(int id) throws BookStoreException;
}
