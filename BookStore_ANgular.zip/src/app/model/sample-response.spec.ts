import { SampleResponse } from './sample-response';

describe('SampleResponse', () => {
  it('should create an instance', () => {
    expect(new SampleResponse()).toBeTruthy();
  });
});
