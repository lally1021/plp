import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { MenuComponent } from './components/menu/menu.component';
import { HttpClientModule } from '@angular/common/http';
import { CategorylistComponent } from './components/category/CategoryList/categorylist.component';
import { AddCategoryComponent } from './components/category/AddCategory/add-category.component';
import { EditCategoryComponent } from './components/category/EditCategory/edit-category.component';
import { ReviewListComponent } from './components/review/review-list/review-list.component';
import { EditComponent } from './components/review/edit/edit.component';
import { CreatecustomerComponent } from './components/customer/createcustomer/createcustomer.component';
import { CustomermanagementComponent } from './components/customer/customermanagement/customermanagement.component';
import { CustprofileComponent } from './components/customer/custprofile/custprofile.component';
import { EditcustomerComponent } from './components/customer/editcustomer/editcustomer.component';
import { CreateuserComponent } from './components/user/components/createuser/createuser.component';
import { EdituserComponent } from './components/user/components/edituser/edituser.component';
import { UsermanagementComponent } from './components/user/components/usermanagement/usermanagement.component';
import { AddnewbookComponent } from './components/book/addnewbook/addnewbook.component';
import { BooklistComponent } from './components/book/booklist/booklist.component';
import { EditbookComponent } from './components/book/editbook/editbook.component';
import { ShowOrderComponent } from './components/order/show-order/show-order.component';
import { DetailsOrderComponent } from './components/order/details-order/details-order.component';
import { HomepageComponent } from './components/homepage/homepage/homepage.component';
import { SigninComponent } from './components/homepage/signin/signin.component';
import { PrivacypolicyComponent } from './components/homepage/privacypolicy/privacypolicy.component';
import { HistoryComponent } from './components/homepage/history/history.component';
import { RegisterComponent } from './components/homepage/register/register.component';
import { ShippinganddeliveryComponent } from './components/homepage/shippinganddelivery/shippinganddelivery.component';
import { AboutusComponent } from './components/homepage/aboutus/aboutus.component';
import { CartComponent } from './components/homepage/cart/cart.component';
import { ContactusComponent } from './components/homepage/contactus/contactus.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/homepage/footer/footer.component';
import { UserfooterComponent } from './components/user/userfooter/userfooter.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    MenuComponent,
    CategorylistComponent,
    AddCategoryComponent,
    EditCategoryComponent,
    ReviewListComponent,
    EditComponent,
    CreatecustomerComponent,
    CustomermanagementComponent,
    CustprofileComponent,
    EditcustomerComponent,
    CreateuserComponent,
    EdituserComponent,
    UsermanagementComponent,
    AddnewbookComponent,
    BooklistComponent,
    EditbookComponent,
    ShowOrderComponent,
    DetailsOrderComponent,
    HomepageComponent,
    SigninComponent,
    PrivacypolicyComponent,
    HistoryComponent,
    RegisterComponent,
    ShippinganddeliveryComponent,
    AboutusComponent,
    CartComponent,
    ContactusComponent,
    HeaderComponent,
    FooterComponent,
    UserfooterComponent

    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
