import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../model/user';
import { SampleResponse } from '../model/sample-response';

import { Customer } from 'Category/categoryAngular/src/app/bean/customer';
import { Book } from '../components/book/bean/book';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  validUser: User={"id":0,"fullName":"","email":"","password":""};
  url:string="http://localhost:7000/user";
  constructor(private http:HttpClient) { }

   /* private sendRequest(url: string, data: {}): Promise<any> {
    return this.http.post(url, data)
      .toPromise()
      .then(response => response);
  } */

  validateUser(user:User){
     
    console.log("service id"+this.validUser.id);
    
      console.log(this.validUser.fullName);
      return this.http.get(this.url+ "/"+user.email+"/"+user.password);
      
     
  } 

  getAllUser()
  {
    return this.http.get<User[]>(this.url);
  }

  

  getAllCustomers()
  {
    return this.http.get<Customer[]>("http://localhost:7000/customer/list");
  }

  
  getAllBooks()
  {
    return this.http.get<Book[]>("http://localhost:7000/book");
  }
  
  userDetail(user:User){
    if(this.validUser){
      this.validUser=  user;
    }
  }


}
