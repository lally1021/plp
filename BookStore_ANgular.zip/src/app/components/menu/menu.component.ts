import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/service/user.service';
import { Book } from '../book/bean/book';
import { Order } from '../order/model/order';
import { Orderedbook } from '../order/model/orderedbook';
import { OrderService } from '../order/service/order.service';
import { Review } from '../review/review';
import { ReviewsService } from '../review/reviews.service';
import { User } from '../user/bean/user';
import { Customer } from 'Category/categoryAngular/src/app/bean/customer';



@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {

  email:string;
  name:string;
   books: Book[];
   orders:Order[];
  customers:Customer[];
  orderedBook:Orderedbook[];
  reviews:Review[];
  users:User[];
  userCount:number=0;
  orderCount:number=0;
  reviewCount:number=0;
  customerCount:number=0;
  bookCount:number=0;
reviewData:Review={"index":0,"id":0,"bookTitle":'',"rating":0,"customerName":'',"headLine":'',"comments":'',"reviewDate":null};

  constructor(private userService: UserService,private orderService:OrderService,private service:ReviewsService) { }

  ngOnInit() {
    this.email = this.userService.validUser.email;
    this.name = this.userService.validUser.fullName;
    console.log(this.email);
    console.log(this.name);
    this.orderService.getAllUsers().subscribe((data:Order[])=>{this.orders=data;
      this.orderCount = data.length;
      console.log(this.orders)});

      this.service.getAllReviews().subscribe((data:Review[])=>{this.reviews=data;
        this.reviewCount = data.length;
      });
   this.userService.getAllUser().subscribe((data:User[])=>{
    
    this.userCount=data.length;})
    this.userService.getAllBooks().subscribe((d:Book[])=>{
    
      this.bookCount=d.length;})
      this.userService.getAllCustomers().subscribe((d:Customer[])=>{
    
        this.customerCount=d.length;})
    
  }
  
  
  calculateCopies(i:number)
  {
   let count:number = 0;
    let order:Order[] = this.orders.filter(item => item.id === i) ;
    order.forEach(element => {
      element.books.forEach(e => {
        count = count + e.quantity;
      });
    });
    console.log(count);
    return count;
  }

  calculateTotal(i:number)
  {
    let total:number = 0;
    let order:Order[] = this.orders.filter(item => item.id === i) ;
    order.forEach(element => {
      element.books.forEach(e => {
       total = total + e.book.price * e.quantity;
      });
    });
    return total;
  }

  deleteReview(review:Review){
    if (window.confirm(" Are you sure you want to delete the review with id "+review.id)) { 
    //window.open("review", "Thanks for Visiting!");
    this.service.deleteReview(review).subscribe((data)=>{this.reviews=this.reviews.filter(c=>c!==review)});
    }
  }

  editReview(review:Review){
    this.service.getById(review.id).subscribe((data)=>{this.reviews=this.reviews.filter(c=>c!==review)});
    }
}
