import { Component, OnInit } from '@angular/core';
import { CategoryService } from '../category.service';
import { Router } from '@angular/router';
import { Category } from '../category.interface';

@Component({
  selector: 'app-add-category',
  templateUrl: './add-category.component.html',
  styleUrls: ['./add-category.component.css']
})
export class AddCategoryComponent implements OnInit {
  categoryData:Category={"id":0,"categoryName":''}
  constructor(private categoryService:CategoryService,private router:Router) { }

  ngOnInit() {
  }
  addCategory(){
   
    console.log(this.categoryData.categoryName);
    console.log(this.categoryData);
      this.categoryService.addCategory(this.categoryData).subscribe((data)=>{this.router.navigate(['menu/categoryList']);});
      
    }
}
