import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Category } from './category.interface';

@Injectable({
  providedIn: 'root'
})
export class CategoryService {
  url:string="http://localhost:7000/category";
  constructor(private http:HttpClient) { }
  addCategory(category:Category){
    return this.http.post(this.url,category);
  }
  getAllCategories(){
    return this.http.get<Category[]>(this.url);
  }
  deleteCategory(category:Category){
    return this.http.delete<Category[]>(this.url+"/"+category.id);
  }
  updateCategory(category:Category){
    
    return this.http.put(this.url+"/"+category.id,category);
  }
  getCategory(id:number){
    console.log(this.url+"/"+id);
    return this.http.get<Category>(this.url+"/"+id);
  }
}
