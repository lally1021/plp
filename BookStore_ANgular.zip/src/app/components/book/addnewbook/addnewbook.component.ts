import { Component, OnInit } from '@angular/core';
import { BookService } from 'src/app/components/book/service/book.service';
import { Book } from '../bean/book';
import { Router } from '@angular/router';
import { CategoryService } from '../../category/category.service';
import { Category } from '../bean/category';

@Component({
  selector: 'app-addnewbook',
  templateUrl: './addnewbook.component.html',
  styleUrls: ['./addnewbook.component.css']
})
export class AddnewbookComponent implements OnInit {

  categories : Category[];
  bookCategory:String;
  book:Book={"id":0,
          "category":{"categoryName":'',"id":0},
        "title":'',
        "author":'',
        "isbn":'',
        "purchaseDate":null,
        "bookImage":'',
        "price":0,
        "description":'',
        "reviews":null};
   
  constructor(private bookService: BookService, private router: Router,private category:CategoryService) { }

  ngOnInit() {
    this.category.getAllCategories().subscribe((data:Category[])=>this.categories = data)
    
    
  }

  addBook(book: Book) {
    this.bookService.addBook(this.book).subscribe(
      (data => this.router.navigate(['menu/bookList'])));
  }
  categoryName(catName:string){
    
    this.categories.forEach(element => {
      console.log(element);
      if(catName === element.categoryName){
        console.log("if");
        this.book.category = element;
      }
    });

    
    
  }
}
