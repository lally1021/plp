import { Component, OnInit } from '@angular/core';
import { Book } from '../bean/book';
import { BookService } from 'src/app/components/book/service/book.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Category } from 'Category/categoryAngular/src/app/category/category.interface';
import { CategoryService } from '../../category/category.service';

@Component({
  selector: 'app-editbook',
  templateUrl: './editbook.component.html',
  styleUrls: ['./editbook.component.css']
})
export class EditbookComponent implements OnInit {
  categories : Category[];
  editedbook:Book={"id":0,
          "category":null,
        "title":'',
        "author":'',
        "isbn":'',
        "purchaseDate":null,
        "bookImage":'',
        "price":0,
        "description":'',
        "reviews":null};
        
  constructor(private bookService: BookService,private router:Router, private route: ActivatedRoute,private category:CategoryService) { }

  ngOnInit() {
    this.route.params.subscribe(
      (params)=>{
        this.bookService.getById(params['id'])
    .subscribe(
      (result)=>{this.editedbook=result;}
      )});

      this.category.getAllCategories().subscribe((data:Category[])=>this.categories = data)
  }

  editBook(book:Book) {
    this.bookService.editBook(this.editedbook).subscribe(
      (data => {this.router.navigate(['menu/bookList'])}));
  }
  categoryName(category:Category){
    this.editedbook.category = category;
    return this.editedbook.category.categoryName;
  }
}
