import { Component, OnInit } from '@angular/core';
import { Book } from '../bean/book';
import { BookService } from 'src/app/components/book/service/book.service';
import { Category } from '../bean/category';

@Component({
  selector: 'app-booklist',
  templateUrl: './booklist.component.html',
  styleUrls: ['./booklist.component.css']
})
export class BooklistComponent implements OnInit {

  books: Book[];
  categories:Category[]
  constructor(private bookService: BookService) { }

  ngOnInit() {
    this.bookService.getBooks().subscribe((data:Book[])=>{
      this.books=data;
      console.log(this.books)
    });
    
    
}

  delete(book:Book){
    this.bookService.delete(book.id);
  }
}
