import { Injectable } from '@angular/core';
import { Book } from '../bean/book';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BookService {
  
  url="http://localhost:7000";
  constructor(private http: HttpClient) {
  }

  addBook(book:Book) {
    console.log(book);
    return this.http.post(this.url+"/book",book);
  }
  getBooks() {
    return this.http.get<Book[]>(this.url+"/book");
  }
  delete(id:number){
    return this.http.delete<Book[]>(this.url + "/book/" + id);
  }
  editBook(book:Book){
    return this.http.put(this.url+"/book",book);
  }
  getById(id:number){
    return this.http.get<Book>(this.url+"/book/"+id);
  }
}
