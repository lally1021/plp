import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/components/user/bean/user';
import { UserService } from 'src/app/components/user/service/user.service';

@Component({
  selector: 'app-usermanagement',
  templateUrl: './usermanagement.component.html',
  styleUrls: ['./usermanagement.component.css']
})
export class UsermanagementComponent implements OnInit {
  users:User[];
  constructor(private userService:UserService) { }

  ngOnInit() {
    this.userService.getAllUser().subscribe(
      (userData:User[])=>{this.users=userData;
                          console.log("all"+this.users)});
  }
  deleteUser(user:User){

    if (window.confirm(" Are you sure you want to delete the user with id "+user.id)) { 
    this.userService.deleteUser(user).subscribe((userData)=>{this.users=this.users.filter(c=>c!==user)});
  }

}

  }