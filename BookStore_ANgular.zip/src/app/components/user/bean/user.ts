export class User {
   
    id:number;
    email:string;
    fullName:string;
    password:string;
}
