import { Component, OnInit } from '@angular/core';
import { BookService } from 'src/app/components/book/service/book.service';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {
 
  constructor(private bookService:BookService) { }


  ngOnInit() {
  }
}
