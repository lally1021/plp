export class Review {
    index:number;
    id:number;
    bookTitle:string;
    rating:number;
    customerName:string;
    headLine:string;
    comments:string;
    reviewDate:Date;
}
