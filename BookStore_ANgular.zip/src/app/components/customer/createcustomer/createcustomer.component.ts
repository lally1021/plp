import { Component, OnInit } from '@angular/core';
import { CustomerserviceService } from '../customerservice.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Customer } from '../customer';

@Component({
  selector: 'app-createcustomer',
  templateUrl: './createcustomer.component.html',
  styleUrls: ['./createcustomer.component.css']
})
export class CreatecustomerComponent implements OnInit {
  customerData:Customer={"id":0,"email":'',"fullName":'',"password":'',"phoneNumber":0,"address":'',"zipcode":0,"city":'',"country":'',"registerDate":null}
  constructor(private customerService:CustomerserviceService,private router:Router,
    private route:ActivatedRoute) { }

  ngOnInit() {
    console.log(this.customerData);
  }
  create(){
    console.log(this.customerData.fullName);
    this.customerService.createCustomer(this.customerData).subscribe(
      (data)=>{this.router.navigate(['menu/customerList']);});
    
      
  }
}
