import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { Router, ActivatedRoute } from '@angular/router';
import { CustomerserviceService } from '../customerservice.service';

@Component({
  selector: 'app-editcustomer',
  templateUrl: './editcustomer.component.html',
  styleUrls: ['./editcustomer.component.css']
})
export class EditcustomerComponent implements OnInit {
customers:Customer[];
  customerData:Customer={"id":0,"email":'',"fullName":'',"password":'',"phoneNumber":0,"address":'',"zipcode":0,"city":'',"country":'',"registerDate":null}
  constructor(private customerService:CustomerserviceService, 
private router:Router,private route:ActivatedRoute) { }
  ngOnInit() {
    this.route.params.subscribe((params)=>{this.customerService.getById(params['id']).subscribe((result)=>{this.customerData=result;})})
  }
  editCustomer(customer:Customer){
   console.log(this.customerData);
      this.customerService.editCustomer(customer).subscribe((data)=>{this.router.navigate(['menu/customerList']);});}
    
  }

