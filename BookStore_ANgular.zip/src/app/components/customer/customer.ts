export class Customer {
  
    id: number;
    email:string;
    fullName:string;
    password:string;
    phoneNumber:number;
    address:string;
    city:string;
    zipcode:number;
    country:string;
    registerDate:Date;
    
}