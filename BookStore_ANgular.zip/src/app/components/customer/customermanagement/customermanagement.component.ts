import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerserviceService } from '../customerservice.service';
import { Customer } from '../customer';

@Component({
  selector: 'app-customermanagement',
  templateUrl: './customermanagement.component.html',
  styleUrls: ['./customermanagement.component.css']
})
export class CustomermanagementComponent implements OnInit {

  customers:Customer[];
  customerData:Customer={"id":0,"email":'',"fullName":'',"password":'',"phoneNumber":0,"address":'',"zipcode":0,"city":'',"country":'',"registerDate":null}
  constructor(private customerService:CustomerserviceService,private route:Router) { }

  ngOnInit() {
    
    this.customerService.getAllCustomers().subscribe
    ((data:Customer[])=>{this.customers=data;
    console.log("all"+this.customers)});
  }
  deleteCustomer(customer:Customer){
    if (window.confirm(" Are you sure you want to delete the customer with id "+customer.id)) { 
    
    this.customerService.deleteCustomer(customer).subscribe((data)=>{this.customers=this.customers.filter(c=>c!==customer)});
    }


    

  }
  editCustomer(customer:Customer){
    this.customerService.getById(customer.id).subscribe((data)=>{this.customers=this.customers.filter(c=>c!==customer)});
    }

}

