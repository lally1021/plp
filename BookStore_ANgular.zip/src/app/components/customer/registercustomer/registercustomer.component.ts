import { Component, OnInit } from '@angular/core';
import { CustomerserviceService } from '../customerservice.service';
import { Customer } from '../customer';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-registercustomer',
  templateUrl: './registercustomer.component.html',
  styleUrls: ['./registercustomer.component.css']
})
export class RegistercustomerComponent implements OnInit {

  constructor(private customerService:CustomerserviceService,private router:Router,private route:ActivatedRoute) { }
  customerData:Customer={"id":0,"email":'',"fullName":'',"password":'',"phoneNumber":0,"address":'',"zipcode":0,"city":'',"country":'',"registerDate":null}
  ngOnInit() {
    console.log(this.customerData);

    /* this.route.params.subscribe((params)=>{this.customerService.getById(params['id']).subscribe((result)=>{this.customerData=result;})}) */
  }
  register(){
    console.log(this.customerData.fullName);
    this.customerService.createCustomer(this.customerData).subscribe(
      (data)=>{this.router.navigate(['customermanagement']);});
    
      
  }
}
