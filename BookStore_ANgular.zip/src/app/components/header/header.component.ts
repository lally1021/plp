import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/model/user';
import { UserService } from '../../service/user.service'
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  validUser:User= {"id":0,"fullName":"","email":"","password":""};
  constructor(private userService: UserService) { }

  ngOnInit() {
    if(this.userService != null){
      this.validUser=  this.userService.validUser;
    }
  
  }

}
