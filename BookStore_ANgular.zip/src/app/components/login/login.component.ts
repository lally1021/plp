import { Component, OnInit } from '@angular/core';
import { Router} from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { User } from 'src/app/model/user';
import { UserService } from '../../service/user.service'


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  validUser:User= {"id":0,"fullName":"","email":"","password":""};
  constructor(private route:Router, private userService: UserService, private formBuilder: FormBuilder) {  }

  ngOnInit() {
  }

  login()
 {
  this.userService.validateUser(this.validUser).subscribe((data:User)=>{
    this.validUser=data;
    if(this.validUser.id)
 {
  console.log(this.validUser.id);
  alert("Login Successfull");
  this.route.navigate(['menu']);
  
  this.userService.userDetail(this.validUser);
  
 }
 else
 {
  console.log(this.validUser.id);
  alert("Login Denied");
  
 }
  });

 
 }
  

}
