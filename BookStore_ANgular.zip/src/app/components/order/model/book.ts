import { Category } from 'src/app/components/category/category.interface';

export class Book {
    id:number;
	category: Category;
	title:string;
	author:string;
	isbn:string;
	purchaseDate:string;
	bookImage:string;
	price:number;
	description:string;
}
