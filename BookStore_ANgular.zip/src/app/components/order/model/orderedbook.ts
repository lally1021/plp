import { Book } from './book';

export class Orderedbook {
	id:number;
	book:Book;
	quantity:number;
}
