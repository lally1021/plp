import { Orderedbook } from './orderedbook';

export class Order {
    id:number;
    orderDate:string;
    paymentMethod:string;
    recipientName:string;
    recipientPhone:string;
    shipTo:string;
    status:string;
    customerId:number;
    books:Orderedbook[];
}
