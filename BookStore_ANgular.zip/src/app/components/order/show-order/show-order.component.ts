import { Component, OnInit } from '@angular/core';
import { Order } from '../model/order';
import { OrderService} from '../service/order.service'
import { Book } from '../model/book';
import { Orderedbook } from '../model/orderedbook';

@Component({
  selector: 'app-show-order',
  templateUrl: './show-order.component.html',
  styleUrls: ['./show-order.component.css']
})
export class ShowOrderComponent implements OnInit {
  orders:Order[];
  book:Book[];
  orderedBook:Orderedbook[];
  constructor(private orderService:OrderService) { }

  ngOnInit() {
    this.orderService.getAllUsers().subscribe((data:Order[])=>{this.orders=data;
      console.log(this.orders)});
  }

  calculateCopies(i:number)
  {
   let count:number = 0;
    let order:Order[] = this.orders.filter(item => item.id === i) ;
    order.forEach(element => {
      element.books.forEach(e => {
        count = count + e.quantity;
      });
    });
    console.log(count);
    return count;
  }

  calculateTotal(i:number)
  {
    let total:number = 0;
    let order:Order[] = this.orders.filter(item => item.id === i) ;
    order.forEach(element => {
      element.books.forEach(e => {
       total = total + e.book.price * e.quantity;
      });
    });
    return total;
  }
}
