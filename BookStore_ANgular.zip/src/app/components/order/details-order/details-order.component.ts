import { Component, OnInit } from '@angular/core';
import { Order } from '../model/order';
import { OrderService} from '../service/order.service'
import {Router, ActivatedRoute} from '@angular/router';
import { Orderedbook } from '../model/orderedbook';
import { Book } from '../model/book';
@Component({
  selector: 'app-details-order',
  templateUrl: './details-order.component.html',
  styleUrls: ['./details-order.component.css']
})
export class DetailsOrderComponent implements OnInit {
  orderData:Order={"id":0,"orderDate":"","paymentMethod":"","recipientName":"","recipientPhone":"","shipTo":"","status":"","books":null,"customerId":0};
  orderedBooks:Orderedbook[];
  book:Book[];
  constructor(private orderService:OrderService,
    private router:Router,private route:ActivatedRoute) { }

  ngOnInit() {
    
    this.route.params.subscribe((params) => {
      this.orderService.getOrder(params['id'])
      .subscribe((result) => { this.orderData = result; console.log(this.orderData);
        console.log(this.orderData.books);
        this.orderData.books.forEach(element => {
          this.book.forEach(e=> e=element.book);
        });
        console.log("books"+this.book); })
      });
  }
  calculateCopies()
  {
   let count:number = 0;
  
      this.orderData.books.forEach(e => {
        count = count+ e.quantity;
      });
    return count;
  }

  calculateTotal()
  {
    let total:number = 0;
    this.orderData.books.forEach(e => {
       total = total + e.book.price * e.quantity;
      });
    return total;
  }

  subtotal(i:number)
  {
    let total:number = 0; 
    this.orderData.books.forEach(e=>
      total =  e.book.price* e.quantity);
      return total;
  }
}
