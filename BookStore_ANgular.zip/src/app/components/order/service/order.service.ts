import { Injectable } from '@angular/core';
import { Order } from '../model/order';
import { HttpClient } from '@angular/common/http'
import { Orderedbook } from '../model/orderedbook';
@Injectable({
  providedIn: 'root'
})
export class OrderService {
  orderUrl: string= 'http://localhost:7000/';
  constructor(private http:HttpClient) { }
  getAllUsers(){
    return this.http.get<Order[]>(this.orderUrl+"orders");
  }
  getOrder(id:number){
    return this.http.get<Order>(this.orderUrl+"order/"+id);
  }
  
  
}
