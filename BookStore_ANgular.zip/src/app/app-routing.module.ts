import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { MenuComponent } from './components/menu/menu.component';
import { CategorylistComponent } from './components/category/CategoryList/categorylist.component';
import { AddCategoryComponent } from './components/category/AddCategory/add-category.component';
import { EditCategoryComponent } from './components/category/EditCategory/edit-category.component';
import { ReviewListComponent } from './components/review/review-list/review-list.component';
import { EditComponent } from './components/review/edit/edit.component';
import { CreatecustomerComponent } from './components/customer/createcustomer/createcustomer.component';
import { CustomermanagementComponent } from './components/customer/customermanagement/customermanagement.component';
import { CustprofileComponent } from './components/customer/custprofile/custprofile.component';
import { EditcustomerComponent } from './components/customer/editcustomer/editcustomer.component';
import { CreateuserComponent } from './components/user/components/createuser/createuser.component';
import { EdituserComponent } from './components/user/components/edituser/edituser.component';
import { UsermanagementComponent } from './components/user/components/usermanagement/usermanagement.component';
import { AddnewbookComponent } from './components/book/addnewbook/addnewbook.component';
import { BooklistComponent } from './components/book/booklist/booklist.component';
import { EditbookComponent } from './components/book/editbook/editbook.component';
import { ShowOrderComponent } from './components/order/show-order/show-order.component';
import { DetailsOrderComponent } from './components/order/details-order/details-order.component';
import { HomepageComponent } from './components/homepage/homepage/homepage.component';
import { SigninComponent } from './components/homepage/signin/signin.component';
import { PrivacypolicyComponent } from './components/homepage/privacypolicy/privacypolicy.component';
import { HistoryComponent } from './components/homepage/history/history.component';
import { RegisterComponent } from './components/homepage/register/register.component';
import { ShippinganddeliveryComponent } from './components/homepage/shippinganddelivery/shippinganddelivery.component';
import { AboutusComponent } from './components/homepage/aboutus/aboutus.component';
import { CartComponent } from './components/homepage/cart/cart.component';
import { ContactusComponent } from './components/homepage/contactus/contactus.component';

const routes: Routes = [
  {path:'login', component:LoginComponent},
  {path:'menu', component:MenuComponent},
  {path:'menu/categoryList', component:CategorylistComponent},
  {path:'menu/categoryList/add', component:AddCategoryComponent},
  {path:'menu/categoryList/editCat/:id', component:EditCategoryComponent},
  {path:'menu/reviewList', component:ReviewListComponent},
  {path:'editRev/:id', component:EditComponent},
  {path:'menu/customerList', component:CustomermanagementComponent},
  {path:'menu/customerProfile', component:CustprofileComponent},
  {path:'editCust/:id', component:EditcustomerComponent},
  {path:'menu/customerList/register', component:CreatecustomerComponent},
  {path:'menu/userList/create', component:CreateuserComponent},
  {path:'menu/userList/editUser/:id', component:EdituserComponent},
  {path:'menu/userList', component:UsermanagementComponent},
  {path:'menu/bookList', component:BooklistComponent},
  {path:'menu/bookList/editbook/:id', component:EditbookComponent},
  {path:'menu/bookList/add', component:AddnewbookComponent},
  {path:'menu/orders', component:ShowOrderComponent},
  {path:'menu/orders/details/:id', component:DetailsOrderComponent},
  {path:'', component:HomepageComponent},
  {path:'signin', component:SigninComponent},
  {path:'privacypolicy', component:PrivacypolicyComponent},
  {path:'history', component:HistoryComponent},
  {path:'register', component:RegisterComponent},
  {path:'shipping', component:ShippinganddeliveryComponent},
  {path:'about', component:AboutusComponent},
  {path:'cart', component:CartComponent},
  {path:'contact', component:ContactusComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
