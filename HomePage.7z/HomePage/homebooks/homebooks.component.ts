import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homebooks',
  templateUrl: './homebooks.component.html',
  styleUrls: ['./homebooks.component.css']
})
export class HomebooksComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
